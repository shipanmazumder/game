<template>
<div>
    <layout>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>Dashboard</p>
                </div>
            </div>
        </div>
    </layout>
</div>
</template>

<script>
export default {
    props: ['fname', 'lname']
}
</script>

<style lang="scss" scoped>

</style>
