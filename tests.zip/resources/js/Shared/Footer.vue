<template>
<div>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 text-left">
                    Copyright &copy; 2020 <a target="_blank" href="https://www.unicef.org/bangladesh/">UNICEF Bangladesh</a>. All rights reserved.
                </div>
                <div class="col-md-6 text-right">
                    Designed &amp; Developed By <a style="color: #F26A11" target="_blank" href="https://riseuplabs.com/">RiseUp Labs</a>
                </div>
            </div>
        </div>
    </footer>

</div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

</style>
