<?php

namespace App\Components;

class Analytics
{
    private $tid="UA-124655500-1";
    /**
     * setEvent
     *
     * @param  client_id $cid
     * @param  event_category $ec
     * @param  event_action $ea
     * @param  event_label $el
     * @param  event_value $ev
     * @return void
     */
    public function setEvent($cid,$ec,$ea="click",$el="button",$ev="Click Here")
    {
        $data = http_build_query(array(
            'v'=>	1,	// version
            'ds'=>	'app',	// data source
            'tid'=>	$this->tid,	// Tracking ID / Web Property ID
            'cid'=>	$cid,	// Client ID
            'uip'=>	$this->ip(),	// IP Override
            't'=>'event',		// Hit type
            'ec'=>	$ec,	// event category
            'ea'=>	$ea,		// event action
            'el'=>	$el,	// event label
            'ev'=>	$ev	// event value
        ));
        // GA curl
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,'https://www.google-analytics.com/collect');
        curl_setopt($ch,CURLOPT_HEADER,true);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_POST,true);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
        $response = curl_exec($ch);

        //parse the response and send back to the browser
        header('Content-Type: application/json');
        $status = curl_getinfo($ch,CURLINFO_HTTP_CODE);
        return $status;
    }
    public function ip() {
		$ip = false;
		if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = explode(',',$_SERVER['HTTP_X_FORWARDED_FOR']);
			$ip = trim(array_shift($ip));
		}
		elseif(isset($_SERVER['REMOTE_ADDR'])) {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
}
